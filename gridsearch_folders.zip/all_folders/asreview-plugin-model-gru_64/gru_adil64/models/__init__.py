from gru_adil64.models.gru64 import GatedRecurrentUnit64
