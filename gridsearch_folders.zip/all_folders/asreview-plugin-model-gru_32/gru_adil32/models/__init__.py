from gru_adil32.models.gru32 import GatedRecurrentUnit32
